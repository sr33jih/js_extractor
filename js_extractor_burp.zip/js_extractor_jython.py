# -*- coding: utf-8 -*-
# js_extractor_jython.py - Burp Suite Extension
# Compatible with Jython 2.7 and Burp Extender API
# Add your full working code here

from burp import IBurpExtender

class BurpExtender(IBurpExtender):
    def registerExtenderCallbacks(self, callbacks):
        callbacks.setExtensionName("JS Extractor")
        print("JS Extractor loaded in Burp Suite")
